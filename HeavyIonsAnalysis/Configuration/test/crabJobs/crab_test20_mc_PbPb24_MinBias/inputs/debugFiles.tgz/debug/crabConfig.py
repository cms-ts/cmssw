from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test20_mc_PbPb24_MinBias'
config.section_('JobType')
config.JobType.maxMemoryMB = 2500
config.JobType.allowUndistributedCMSSW = True
config.JobType.maxJobRuntimeMin = 1200
config.JobType.psetName = 'forest_miniAOD_run3_MC_MinBias.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDataset = '/MinBias_Drum5F_5p36TeV_hydjet/HINPbPbWinter24MiniAOD-NoPU_141X_mcRun3_2024_realistic_HI_v14-v2/MINIAODSIM'
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'CRAB3_Analysis_test20_mc_PbPb24_MinBias'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
