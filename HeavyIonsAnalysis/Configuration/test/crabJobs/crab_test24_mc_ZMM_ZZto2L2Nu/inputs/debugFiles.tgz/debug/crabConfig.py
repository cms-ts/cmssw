from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test24_mc_ZMM_ZZto2L2Nu'
config.section_('JobType')
config.JobType.psetName = 'forest_miniAOD_run3_MC_ZMM.py'
config.JobType.allowUndistributedCMSSW = True
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 1200
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.outputDatasetTag = 'CRAB3_Analysis_test24_ZMM_ZZto2L2Nu'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/ZZto2L2Nu_TuneCP5_5p36TeV_powheg-pythia8/HINPbPbSpring23MiniAOD-132X_mcRun3_2023_realistic_HI_v9-v2/MINIAODSIM'
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
