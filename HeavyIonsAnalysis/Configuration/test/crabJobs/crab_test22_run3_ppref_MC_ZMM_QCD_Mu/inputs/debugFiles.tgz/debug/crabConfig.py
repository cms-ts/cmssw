from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test22_run3_ppref_MC_ZMM_QCD_Mu'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1200
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = 'forest_miniAOD_run3_ppref_MC_ZMM.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.outputDatasetTag = 'CRAB3_Analysis_test22_run3_ppref_MC_ZMM_QCD_Mu'
config.Data.inputDataset = '/QCD-Mu_pThat-20_TuneCP5_5p36TeV_pythia8/RunIIIpp5p36Winter24MiniAOD-141X_mcRun3_2024_realistic_ppRef5TeV_v7-v2/MINIAODSIM'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
