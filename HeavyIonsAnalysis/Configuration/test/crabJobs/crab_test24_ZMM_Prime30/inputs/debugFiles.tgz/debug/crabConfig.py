from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test24_ZMM_Prime30'
config.section_('JobType')
config.JobType.allowUndistributedCMSSW = True
config.JobType.maxJobRuntimeMin = 1200
config.JobType.maxMemoryMB = 2500
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'forest_miniAOD_run3_DATA_ZMM.py'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/HIPhysicsRawPrime30/HIRun2023A-PromptReco-v2/MINIAOD'
config.Data.unitsPerJob = 10
config.Data.publication = False
config.Data.outputDatasetTag = 'CRAB3_Analysis_test24_ZMM_Prime30'
config.Data.splitting = 'LumiBased'
config.Data.lumiMask = 'Cert_Collisions2023HI_374288_375823_Golden.json'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
