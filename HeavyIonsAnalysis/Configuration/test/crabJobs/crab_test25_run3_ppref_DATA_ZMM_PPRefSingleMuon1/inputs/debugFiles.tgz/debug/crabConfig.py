from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test25_run3_ppref_DATA_ZMM_PPRefSingleMuon1'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1200
config.JobType.maxMemoryMB = 2500
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = 'forest_miniAOD_run3_ppref_DATA_ZMM.py'
config.section_('Data')
config.Data.inputDataset = '/PPRefSingleMuon1/Run2024J-PromptReco-v1/MINIAOD'
config.Data.unitsPerJob = 10
config.Data.inputDBS = 'global'
config.Data.lumiMask = 'Cert_Collisions2024_ppref_387474_387721_golden.json'
config.Data.outputDatasetTag = 'CRAB3_Analysis_test25_run3_ppref_DATA_ZMM_PPRefSingleMuon1'
config.Data.splitting = 'LumiBased'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
