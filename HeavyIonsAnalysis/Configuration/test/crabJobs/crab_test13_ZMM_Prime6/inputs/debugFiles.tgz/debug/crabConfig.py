from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test13_ZMM_Prime6'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1200
config.JobType.maxMemoryMB = 2500
config.JobType.psetName = 'forest_miniAOD_run3_DATA_ZMM.py'
config.JobType.allowUndistributedCMSSW = True
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDataset = '/HIPhysicsRawPrime6/HIRun2023A-PromptReco-v2/MINIAOD'
config.Data.lumiMask = 'Cert_Collisions2023HI_374288_375823_Golden.json'
config.Data.inputDBS = 'global'
config.Data.splitting = 'LumiBased'
config.Data.publication = False
config.Data.outputDatasetTag = 'CRAB3_Analysis_test13_ZMM_Prime6'
config.Data.unitsPerJob = 10
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
