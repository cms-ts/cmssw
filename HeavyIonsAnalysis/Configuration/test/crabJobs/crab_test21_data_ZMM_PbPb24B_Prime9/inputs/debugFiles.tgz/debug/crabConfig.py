from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test21_data_ZMM_PbPb24B_Prime9'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1200
config.JobType.allowUndistributedCMSSW = True
config.JobType.maxMemoryMB = 2500
config.JobType.psetName = 'forest_miniAOD_run3_DATA_ZMM.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'LumiBased'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.outputDatasetTag = 'CRAB3_Analysis_test21_ZMM_PbPb24_Prime9'
config.Data.unitsPerJob = 10
config.Data.inputDataset = '/HIPhysicsRawPrime9/HIRun2024B-PromptReco-v1/MINIAOD'
config.Data.lumiMask = 'Cert_Collisions2024_HI_387853_388784_Golden.json'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
