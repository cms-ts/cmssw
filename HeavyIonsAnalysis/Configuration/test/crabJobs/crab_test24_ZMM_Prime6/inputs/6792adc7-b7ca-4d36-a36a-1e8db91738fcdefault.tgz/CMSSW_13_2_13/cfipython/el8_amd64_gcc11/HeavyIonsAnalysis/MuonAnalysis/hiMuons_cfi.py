import FWCore.ParameterSet.Config as cms

hiMuons = cms.EDProducer('HIMuonMVAProducer',
  muons = cms.InputTag('slimmedMuons'),
  pfCandidates = cms.InputTag('packedPFCandidates'),
  centrality = cms.InputTag('centralityBin', 'HFtowers'),
  etaMap = cms.InputTag('hiFJRhoProducerFinerBins', 'mapEtaEdges'),
  rhoMap = cms.InputTag('hiFJRhoProducerFinerBins', 'mapToRho'),
  pf_maxAbsEta = cms.double(2.8),
  sk_radius = cms.double(0.4),
  muon_minPt = cms.double(0),
  iso_rVeto = cms.double(0.001),
  iso_rCone = cms.double(0.3),
  file_isoModel = cms.FileInPath('HeavyIonsAnalysis/MuonAnalysis/data/muiso_BDT.root'),
  file_isoCorr = cms.FileInPath('HeavyIonsAnalysis/MuonAnalysis/data/lepton_spectra_train_weights.json.gz'),
  mightGet = cms.optional.untracked.vstring
)
