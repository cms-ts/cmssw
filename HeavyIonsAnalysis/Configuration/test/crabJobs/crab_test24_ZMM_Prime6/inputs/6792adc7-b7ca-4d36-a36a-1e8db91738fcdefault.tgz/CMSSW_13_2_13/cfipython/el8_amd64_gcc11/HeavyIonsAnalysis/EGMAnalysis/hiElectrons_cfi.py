import FWCore.ParameterSet.Config as cms

hiElectrons = cms.EDProducer('HIElectronInfoProducer',
  electrons = cms.InputTag('slimmedElectrons'),
  pfCandidates = cms.InputTag('packedPFCandidates'),
  centrality = cms.InputTag('centralityBin', 'HFtowers'),
  etaMap = cms.InputTag('hiFJRhoProducerFinerBins', 'mapEtaEdges'),
  rhoMap = cms.InputTag('hiFJRhoProducerFinerBins', 'mapToRho'),
  pf_maxAbsEta = cms.double(2.8),
  sk_radius = cms.double(0.4),
  electron_minPt = cms.double(0),
  iso_rVeto = cms.double(0.026),
  iso_rCone = cms.double(0.3),
  file_idModel = cms.FileInPath('HeavyIonsAnalysis/EGMAnalysis/data/eleid_BDT.root'),
  file_isoModel = cms.FileInPath('HeavyIonsAnalysis/EGMAnalysis/data/eleiso_BDT.root'),
  file_corr = cms.FileInPath('HeavyIonsAnalysis/EGMAnalysis/data/lepton_spectra_train_weights.json.gz'),
  mightGet = cms.optional.untracked.vstring
)
