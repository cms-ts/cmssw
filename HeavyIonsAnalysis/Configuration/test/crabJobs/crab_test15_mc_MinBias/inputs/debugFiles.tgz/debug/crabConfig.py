from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test15_mc_MinBias'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.JobType.maxJobRuntimeMin = 1200
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = 'forest_miniAOD_run3_MC_MinBias.py'
config.section_('Data')
config.Data.outputDatasetTag = 'CRAB3_Analysis_test15_mc_MinBias'
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/MinBias_Drum5F_5p36TeV_hydjet/HINPbPbSpring23MiniAOD-NoPU_132X_mcRun3_2023_realistic_HI_v9-v2/MINIAODSIM'
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
