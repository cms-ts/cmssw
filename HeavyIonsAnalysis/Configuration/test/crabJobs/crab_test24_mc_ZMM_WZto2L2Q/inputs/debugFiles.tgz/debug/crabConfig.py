from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test24_mc_ZMM_WZto2L2Q'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1200
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.JobType.psetName = 'forest_miniAOD_run3_MC_ZMM.py'
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'CRAB3_Analysis_test24_ZMM_WZto2L2Q'
config.Data.inputDataset = '/WZto2L2Q_TuneCP5_5p36TeV_powheg-pythia8/HINPbPbSpring23MiniAOD-132X_mcRun3_2023_realistic_HI_v9-v2/MINIAODSIM'
config.Data.unitsPerJob = 1
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
