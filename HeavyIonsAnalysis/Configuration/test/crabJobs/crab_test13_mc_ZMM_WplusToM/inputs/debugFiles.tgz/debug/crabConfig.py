from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test13_mc_ZMM_WplusToM'
config.section_('JobType')
config.JobType.maxMemoryMB = 2500
config.JobType.psetName = 'forest_miniAOD_run3_MC_ZMM.py'
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.maxJobRuntimeMin = 1200
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'CRAB3_Analysis_test13_ZMM_WplusToM'
config.Data.publication = False
config.Data.inputDataset = '/WplusToMuplusNu_TuneCP5_5p36TeV_powheg-pythia8/HINPbPbSpring23MiniAOD-132X_mcRun3_2023_realistic_HI_v9-v2/MINIAODSIM'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
