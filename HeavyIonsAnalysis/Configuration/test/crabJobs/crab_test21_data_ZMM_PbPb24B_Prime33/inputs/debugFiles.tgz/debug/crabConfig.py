from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test21_data_ZMM_PbPb24B_Prime33'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1200
config.JobType.maxMemoryMB = 2500
config.JobType.psetName = 'forest_miniAOD_run3_DATA_ZMM.py'
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.lumiMask = 'Cert_Collisions2024_HI_387853_388784_Golden.json'
config.Data.outputDatasetTag = 'CRAB3_Analysis_test21_ZMM_PbPb24_Prime33'
config.Data.unitsPerJob = 10
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.inputDataset = '/HIPhysicsRawPrime33/HIRun2024B-PromptReco-v1/MINIAOD'
config.Data.splitting = 'LumiBased'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
