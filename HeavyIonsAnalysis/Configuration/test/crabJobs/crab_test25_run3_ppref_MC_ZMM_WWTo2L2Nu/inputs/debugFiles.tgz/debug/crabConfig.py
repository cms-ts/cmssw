from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test25_run3_ppref_MC_ZMM_WWTo2L2Nu'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1200
config.JobType.maxMemoryMB = 2500
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'forest_miniAOD_run3_ppref_MC_ZMM.py'
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/WWTo2L2Nu_TuneCP5_5p36TeV_powheg-pythia8/RunIIIpp5p36Winter24MiniAOD-141X_mcRun3_2024_realistic_ppRef5TeV_v7-v1/MINIAODSIM'
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'CRAB3_Analysis_test25_run3_ppref_MC_ZMM_WWTo2L2Nu'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
