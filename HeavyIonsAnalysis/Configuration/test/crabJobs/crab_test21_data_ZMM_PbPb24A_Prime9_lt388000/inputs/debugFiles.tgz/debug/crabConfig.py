from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test21_data_ZMM_PbPb24A_Prime9_lt388000'
config.section_('JobType')
config.JobType.psetName = 'forest_miniAOD_run3_DATA_ZMM_lt388000.py'
config.JobType.allowUndistributedCMSSW = True
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 1200
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.lumiMask = 'Cert_Collisions2024_HI_387853_388784_Golden.json'
config.Data.publication = False
config.Data.inputDataset = '/HIPhysicsRawPrime9/HIRun2024A-PromptReco-v1/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'CRAB3_Analysis_test21_ZMM_PbPb24A_Prime9_lt388000'
config.Data.splitting = 'LumiBased'
config.Data.runRange = '387853-387999'
config.Data.unitsPerJob = 10
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
