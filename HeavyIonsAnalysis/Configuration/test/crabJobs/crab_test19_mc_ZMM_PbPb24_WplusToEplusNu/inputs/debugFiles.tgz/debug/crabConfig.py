from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test19_mc_ZMM_PbPb24_WplusToEplusNu'
config.section_('JobType')
config.JobType.maxMemoryMB = 2500
config.JobType.maxJobRuntimeMin = 1200
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = 'forest_miniAOD_run3_MC_ZMM.py'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'CRAB3_Analysis_test19_ZMM_PbPb24_WplusToEplusNu'
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/WplusToEplusNu_TuneCP5_5p36TeV_powheg-pythia8/HINPbPbWinter24MiniAOD-141X_mcRun3_2024_realistic_HI_v14-v2/MINIAODSIM'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
