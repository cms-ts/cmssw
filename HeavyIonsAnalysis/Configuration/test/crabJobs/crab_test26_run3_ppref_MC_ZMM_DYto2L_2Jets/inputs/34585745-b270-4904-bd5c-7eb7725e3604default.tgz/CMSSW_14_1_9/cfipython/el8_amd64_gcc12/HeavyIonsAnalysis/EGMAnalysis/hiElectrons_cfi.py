import FWCore.ParameterSet.Config as cms

from .HIElectronInfoProducer import HIElectronInfoProducer

hiElectrons = HIElectronInfoProducer()
