import FWCore.ParameterSet.Config as cms

def HIElectronInfoProducer(**kwargs):
  mod = cms.EDProducer('HIElectronInfoProducer',
    electrons = cms.InputTag('slimmedElectrons'),
    pfCandidates = cms.InputTag('packedPFCandidates'),
    centrality = cms.InputTag('centralityBin', 'HFtowers'),
    etaMap = cms.InputTag('hiFJRhoProducerFinerBins', 'mapEtaEdges'),
    rhoMap = cms.InputTag('hiFJRhoProducerFinerBins', 'mapToRho'),
    pf_maxAbsEta = cms.double(2.8),
    sk_radius = cms.double(0.4),
    electron_minPt = cms.double(0),
    iso_rVeto = cms.double(0.026),
    iso_rCone = cms.double(0.3),
    file_idModel = cms.FileInPath(''),
    file_isoModel = cms.FileInPath(''),
    file_corr = cms.FileInPath(''),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
