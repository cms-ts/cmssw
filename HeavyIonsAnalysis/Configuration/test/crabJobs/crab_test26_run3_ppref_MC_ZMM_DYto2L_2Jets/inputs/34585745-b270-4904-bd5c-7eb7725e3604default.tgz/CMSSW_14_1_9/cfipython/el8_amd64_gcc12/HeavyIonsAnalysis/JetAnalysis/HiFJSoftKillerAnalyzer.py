import FWCore.ParameterSet.Config as cms

def HiFJSoftKillerAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('HiFJSoftKillerAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
