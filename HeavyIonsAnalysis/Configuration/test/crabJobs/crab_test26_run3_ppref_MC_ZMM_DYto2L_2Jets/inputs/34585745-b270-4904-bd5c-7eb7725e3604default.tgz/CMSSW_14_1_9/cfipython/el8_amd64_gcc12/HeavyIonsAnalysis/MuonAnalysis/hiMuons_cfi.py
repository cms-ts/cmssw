import FWCore.ParameterSet.Config as cms

from .HIMuonMVAProducer import HIMuonMVAProducer

hiMuons = HIMuonMVAProducer()
