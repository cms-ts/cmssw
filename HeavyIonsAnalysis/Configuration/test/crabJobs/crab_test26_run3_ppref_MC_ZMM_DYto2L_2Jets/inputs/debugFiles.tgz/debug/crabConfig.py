from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test26_run3_ppref_MC_ZMM_DYto2L_2Jets'
config.section_('JobType')
config.JobType.psetName = 'forest_miniAOD_run3_ppref_MC_ZMM_Gen.py'
config.JobType.maxMemoryMB = 2500
config.JobType.maxJobRuntimeMin = 1200
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.outputDatasetTag = 'CRAB3_Analysis_test26_run3_ppref_MC_ZMM_DYto2L_2Jets'
config.Data.inputDataset = '/DYto2L-2Jets_MLL-50_TuneCP5_5p36TeV_amcatnloFXFX-pythia8/RunIIIpp5p36Winter24MiniAOD-141X_mcRun3_2024_realistic_ppRef5TeV_v7-v1/MINIAODSIM'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
