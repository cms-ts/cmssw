from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test24_mc_ZMM_DYto2Mu'
config.section_('JobType')
config.JobType.psetName = 'forest_miniAOD_run3_MC_ZMM_Gen.py'
config.JobType.maxJobRuntimeMin = 1200
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/DYto2Mu_MLL-50_TuneCP5_5p36TeV_powheg-pythia8/HINPbPbSpring23MiniAOD-132X_mcRun3_2023_realistic_HI_v9-v3/MINIAODSIM'
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'CRAB3_Analysis_test24_ZMM_DYto2Mu'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.Site.whitelist = ['T3_IT_Trieste']
config.section_('User')
config.section_('Debug')
