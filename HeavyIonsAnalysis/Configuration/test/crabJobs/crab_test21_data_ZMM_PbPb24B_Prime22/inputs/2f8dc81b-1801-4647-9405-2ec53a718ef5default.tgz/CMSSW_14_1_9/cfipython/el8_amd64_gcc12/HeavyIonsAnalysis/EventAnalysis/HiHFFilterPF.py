import FWCore.ParameterSet.Config as cms

def HiHFFilterPF(**kwargs):
  mod = cms.EDFilter('HiHFFilterPF',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
