import FWCore.ParameterSet.Config as cms

def EmbedL1HLTinMuons(**kwargs):
  mod = cms.EDProducer('EmbedL1HLTinMuons',
    muons = cms.InputTag('unpackedMuons'),
    triggerResults = cms.InputTag('TriggerResults', '', 'HLT'),
    triggerObjects = cms.InputTag('slimmedPatTrigger'),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
