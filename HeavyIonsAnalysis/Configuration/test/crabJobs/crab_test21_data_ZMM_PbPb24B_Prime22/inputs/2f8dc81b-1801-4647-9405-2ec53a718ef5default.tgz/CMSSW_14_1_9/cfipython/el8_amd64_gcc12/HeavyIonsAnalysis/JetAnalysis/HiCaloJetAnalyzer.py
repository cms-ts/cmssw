import FWCore.ParameterSet.Config as cms

def HiCaloJetAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('HiCaloJetAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
