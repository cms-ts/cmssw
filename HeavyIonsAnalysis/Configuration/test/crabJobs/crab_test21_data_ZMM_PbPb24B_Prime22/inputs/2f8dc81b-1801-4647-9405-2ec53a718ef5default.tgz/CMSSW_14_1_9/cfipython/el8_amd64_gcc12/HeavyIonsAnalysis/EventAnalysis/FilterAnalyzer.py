import FWCore.ParameterSet.Config as cms

def FilterAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('FilterAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
