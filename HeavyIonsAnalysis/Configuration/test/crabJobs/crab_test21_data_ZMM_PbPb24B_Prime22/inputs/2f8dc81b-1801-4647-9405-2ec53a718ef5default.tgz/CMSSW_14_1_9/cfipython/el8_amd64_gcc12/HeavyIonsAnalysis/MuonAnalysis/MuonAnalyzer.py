import FWCore.ParameterSet.Config as cms

def MuonAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('MuonAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
