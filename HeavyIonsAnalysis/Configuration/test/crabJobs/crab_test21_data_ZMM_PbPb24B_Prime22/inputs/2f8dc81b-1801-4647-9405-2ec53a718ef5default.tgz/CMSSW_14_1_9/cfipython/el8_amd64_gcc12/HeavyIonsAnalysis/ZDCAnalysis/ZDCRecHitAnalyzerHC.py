import FWCore.ParameterSet.Config as cms

def ZDCRecHitAnalyzerHC(**kwargs):
  mod = cms.EDAnalyzer('ZDCRecHitAnalyzerHC',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
