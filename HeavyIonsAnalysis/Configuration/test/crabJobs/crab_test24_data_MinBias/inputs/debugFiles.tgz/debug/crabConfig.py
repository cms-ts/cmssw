from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'test24_data_MinBias'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1200
config.JobType.psetName = 'forest_miniAOD_run3_DATA_MinBias.py'
config.JobType.maxMemoryMB = 2500
config.JobType.allowUndistributedCMSSW = True
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDataset = '/HIMinimumBias0/HIRun2023A-PromptReco-v2/MINIAOD'
config.Data.unitsPerJob = 10
config.Data.outputDatasetTag = 'CRAB3_Analysis_test24_data_MinBias'
config.Data.splitting = 'LumiBased'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.lumiMask = 'Cert_Collisions2023HI_374288_375823_Golden.json'
config.section_('Site')
config.Site.storageSite = 'T3_IT_Trieste'
config.section_('User')
config.section_('Debug')
